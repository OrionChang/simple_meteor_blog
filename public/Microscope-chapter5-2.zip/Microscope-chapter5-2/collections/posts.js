Posts = new Meteor.Collection('posts');
